<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblImpuestosFacturasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_impuestos_facturas', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('factura_detalle_id')->unsigned()->nullable();
            $table->foreign('factura_detalle_id')->references('id')->on('tbl_facturas_detalles');
            $table->integer('impuesto_id')->unsigned()->nullable();
            $table->foreign('impuesto_id')->references('id')->on('tbl_impuestos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_impuestos_facturas');
    }
}
