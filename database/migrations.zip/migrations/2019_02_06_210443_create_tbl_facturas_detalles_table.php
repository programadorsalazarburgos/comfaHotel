<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblFacturasDetallesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_facturas_detalles', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('factura_id')->unsigned()->nullable();
            $table->foreign('factura_id')->references('id')->on('tbl_facturas');
            $table->integer('reserva_detalle_id')->unsigned()->nullable();
            $table->foreign('reserva_detalle_id')->references('id')->on('tbl_reservas_detalle');
            $table->date('check_in_fecha')->nullable();
            $table->integer('id_habitacion_tipo')->unsigned()->nullable();
            $table->foreign('id_habitacion_tipo')->references('id')->on('tbl_habitaciones_tipo');
            $table->integer('id_habitacion')->nullable(); 
            $table->foreign('id_habitacion')->references('id')->on('tbl_habitaciones');
            $table->double('precio_unitario');
            $table->double('precio_bruto');
            $table->float('descuento', 15, 3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_facturas_detalles');
    }
}
