<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTblHabitacionesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('tbl_habitaciones', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('id_habitacion_tipo')->unsigned()->index('id_habitacion_tipo');
			$table->string('numero', 10);
			$table->integer('piso');
			$table->integer('personas_minimo');
			$table->integer('personas_maximo');
			$table->integer('id_cama')->unsigned()->index('id_cama');
			$table->unique(['id_habitacion_tipo', 'numero']);
			$table->timestamps();
			$table->softDeletes();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('tbl_habitaciones');
	}

}
