<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTblHabitacionesXReservasDetalleTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('tbl_habitaciones_x_reservas_detalle', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('id_reservas_detalle')->unsigned()->index('id_reservas_detalle');
			$table->integer('id_habitacion')->unsigned()->index('id_habitacion');
			$table->string('label', 20)->nullable()->comment('Colores de el panel de control');
			$table->timestamps();
			$table->softDeletes();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('tbl_habitaciones_x_reservas_detalle');
	}

}
