<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblReservasDetalle extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_reservas_detalle',function(Blueprint $table)
        {
            $table->increments('id');
            $table->integer('id_habitacion_tipo');
            $table->integer('id_habitacion')->nullable(); 
            $table->integer('id_reservas_grupo'); 
            $table->integer('huespedes_cantidad')->nullable();
            $table->integer('habitaciones_cantidad')->nullable();
            $table->integer('adultos_cantidad')->nullable();
            $table->integer('ninos_cantidad')->nullable();
            $table->integer('infantes_cantidad')->nullable();
            $table->double('habitacion_precio_total')->nullable();
            $table->double('precio_total')->nullable();
            $table->text('requisitos')->nullable(); 
            $table->text('comentarios')->nullable();
            $table->text('value')->nullable();
            $table->date('check_in_fecha')->nullable();
            $table->date('check_out_fecha')->nullable();
            $table->foreign('id_habitacion_tipo')->references('id')->on('tbl_habitaciones_tipo');
            $table->foreign('id_habitacion')->references('id')->on('tbl_habitaciones');
            $table->foreign('id_reservas_grupo')->references('id')->on('tbl_reservas_grupo');
            $table->integer('id_reserva_detalle_estado_habitacion')->nullable();
            $table->foreign('id_reserva_detalle_estado_habitacion')->references('id')->on('tbl_reservas_estado');
            $table->timestamps();
            $table->softDeletes();
            //

            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbl_reservas_detalle');
    }
}
