<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblReservasDetalleHuespedesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_reservas_detalle_huespedes', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_cliente_huesped')->unsigned();
            $table->integer('id_reservas_detalle')->unsigned();
            $table->boolean('es_cliente_principal')->default(FALSE);
            $table->foreign('id_cliente_huesped')->references('id')->on('tbl_clientes');
            $table->foreign('id_reservas_detalle')->references('id')->on('tbl_reservas_detalle');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_reservas_detalle_huespedes');
    }
}
