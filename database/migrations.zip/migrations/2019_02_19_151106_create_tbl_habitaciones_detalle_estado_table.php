<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblHabitacionesDetalleEstadoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_habitaciones_detalle_estado', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_habitacion');
            $table->integer('id_habitacion_estado');
            $table->text('descripcion')->nullable();;
            $table->date('fecha');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_habitaciones_detalle_estado');
    }
}
