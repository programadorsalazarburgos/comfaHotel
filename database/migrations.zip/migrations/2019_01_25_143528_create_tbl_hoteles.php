<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblHoteles extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
        /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_hoteles', function (Blueprint $table) 
        {
            $table->increments('id');
            $table->string('nombre');
            $table->date('fecha_inicio')->nullable();
            $table->date('fecha_fin')->nullable();
            $table->string('nit')->nullable();
            $table->string('direccion')->nullable();
            $table->string('responsable_nombre')->nullable();
            $table->string('responsable_telefono')->nullable();
            $table->string('api_user')->nullable();
            $table->string('api_password')->nullable();
            $table->string('api_code')->nullable();
            $table->text('comentario')->nullable();
            $table->text('schema');
            
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_hoteles');
    }
}
