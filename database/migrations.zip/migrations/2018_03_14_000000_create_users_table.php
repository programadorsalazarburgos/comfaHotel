<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) 
        {
            $table->increments('id');
            $table->string('nombres', 100)->nullable();
            $table->string('tipo_documento', 100)->nullable();
            $table->string('documento', 100)->nullable();
            $table->string('telefono', 100)->nullable();
            $table->string('email', 100)->unique()->nullable();
            $table->string('usuario')->unique();
            $table->string('schema')->nullable();
            $table->string('password');
            $table->boolean('activo')->default(true);
            $table->integer('idrol')->unsigned();
            $table->foreign('idrol')->references('id')->on('roles');
            $table->integer('hotel_id')->unsigned()->nullable();
            //$table->foreign('hotel_id')->references('id')->on('tbl_hoteles');
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
