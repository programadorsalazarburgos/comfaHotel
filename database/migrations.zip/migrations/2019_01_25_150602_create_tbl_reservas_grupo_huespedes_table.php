<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblReservasGrupoHuespedesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_reservas_grupo_huespedes', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_cliente_huesped');
            $table->integer('id_reservas_grupo');
            $table->foreign('id_reservas_grupo')->references('id')->on('tbl_reservas_grupo');
            $table->foreign('id_cliente_huesped')->references('id')->on('tbl_clientes');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_reservas_grupo_huespedes');
    }
}
