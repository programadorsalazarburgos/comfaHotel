<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTblClientesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('tbl_clientes', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('id_clientes_tipo')->unsigned()->nullable();
            $table->foreign('id_clientes_tipo')->references('id')->on('tbl_clientes_tipo');
			$table->string('nombre', 100);
			$table->string('apellido', 100)->nullable();
			$table->integer('genero_id')->unsigned()->nullable();
            $table->foreign('genero_id')->references('id')->on('tbl_generos');
			$table->date('fecha_nacimiento')->nullable();
			$table->integer('id_nacionalidad')->unsigned()->nullable();
            $table->foreign('id_nacionalidad')->references('id')->on('tbl_paises');
			$table->string('formula', 100)->nullable();
			$table->string('titulo', 100)->nullable();
			$table->integer('id_documento_tipo')->unsigned()->nullable();
            $table->foreign('id_documento_tipo')->references('id')->on('tbl_documento_tipo');
			$table->string('no_documento', 100)->nullable();
			$table->string('nombre_empresa', 100)->nullable();
            $table->string('no_empresa', 100)->nullable();  
            $table->string('nombre_agencia', 100)->nullable();
            $table->string('no_agencia', 100)->nullable();
			$table->string('calle_residencia', 100)->nullable();
			$table->string('lugar_residencia', 100)->nullable();
			$table->string('codigo_postal_residencia', 100)->nullable();
			$table->integer('id_pais_residencia')->unsigned()->nullable();
            $table->foreign('id_pais_residencia')->references('id')->on('tbl_paises');
			$table->integer('id_departamento_residencia')->unsigned()->nullable();
            $table->foreign('id_departamento_residencia')->references('id')->on('tbl_departamentos');
			$table->string('calle_factura')->nullable();
			$table->string('lugar_factura')->nullable();
			$table->string('codigo_postal_factura')->nullable();
			$table->integer('id_pais_factura')->unsigned()->nullable();
            $table->foreign('id_pais_factura')->references('id')->on('tbl_paises');
			$table->integer('id_departamento_factura')->unsigned()->nullable();	
            $table->foreign('id_departamento_factura')->references('id')->on('tbl_departamentos');
			$table->string('comentarios', 500)->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('tbl_clientes');
	}

}
