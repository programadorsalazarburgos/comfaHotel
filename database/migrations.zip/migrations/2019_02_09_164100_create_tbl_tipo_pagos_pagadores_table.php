<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblTipoPagosPagadoresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_tipo_pagos_pagadores', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('pagadores_factura_id')->unsigned()->nullable();
            $table->foreign('pagadores_factura_id')->references('id')->on('tbl_pagadores_facturas');
            $table->integer('tipo_pago_id')->unsigned()->nullable();
            $table->foreign('tipo_pago_id')->references('id')->on('tbl_tipo_pagos');
            $table->double('valor_pagado')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_tipo_pagos_pagadores');
    }
}
